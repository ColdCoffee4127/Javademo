package test;

import java.util.Scanner;

import static test.Choice.*;
import static test.login.Login.login;

/**
 * @ClassName test.BibsMain
 * @description:
 * @author: coldcoffee
 * @create: 2024-06-15 11:45
 * @Version 1.0
 **/
public class BibsMain {
    public static void main(String[] args) {
        Scanner x = new Scanner(System.in);
        int c;
        boolean st = true;
        while (st) {
            System.out.println("=======================��ӭʹ�������м�ҵ��ϵͳ====");
            System.out.println("1.��¼ 2.ע�� 3.ת�� 4.�˳�");
            System.out.print("��ѡ��");
            c = x.nextInt();
            switch (c) {
                case 1:
                    login();
                    break;
                case 2:
                    register();
                    break;
                case 3:
                    transfer();
                    break;
                case 4:
                    st = false;
                    break;
            }
        }
    }

}
