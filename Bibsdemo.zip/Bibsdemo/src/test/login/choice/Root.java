package test.login.choice;

import java.util.Scanner;

/**
 * @ClassName Root
 * @description:
 * @author: coldcoffee
 * @create: 2024-06-15 13:46
 * @Version 1.0
 **/
public class Root {
    public static void root(){
        Scanner x = new Scanner(System.in);
        System.out.println("====================��ӭ�㣺ϵͳ����Ա====================");
        System.out.println("1.������ɫ 2.��ѯ��ɫ 3.�޸Ľ�ɫ 4.�������˵�");
        System.out.print("��ѡ��");

        int y = x.nextInt();

        switch (y){
            case 1:
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                return ;
        }
    }
}
