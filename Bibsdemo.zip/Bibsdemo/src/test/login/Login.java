package test.login;

import java.util.Scanner;

import static test.login.choice.Clerk.clerk;
import static test.login.choice.Manage.manage;
import static test.login.choice.Root.root;

/**
 * @ClassName Login
 * @description:
 * @author: coldcoffee
 * @create: 2024-06-15 13:29
 * @Version 1.0
 **/
public class Login {
    public static void login(){
        //��¼���� ��ɺ� ����ĳ��ֵȷ������
        String username;
        String password;
        Scanner x = new Scanner(System.in);
        System.out.print("�������û�����");
        username = x.next();
        password = x.next();
        System.out.print("���������룺");
        int y;
        switch (y){
            case 1:
                root();
                break;
            case 2:
                clerk();
                break;
            case 3:
                manage();
                break;
        }
    }
}
