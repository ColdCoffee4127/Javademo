package test;

import java.util.Scanner;

/**
 * @ClassName Choice
 * @description:
 * @author: coldcoffee
 * @create: 2024-06-15 13:10
 * @Version 1.0
 **/
public class Choice {

    public static void register(){return ;}
    public static void transfer(){return ;}
}
