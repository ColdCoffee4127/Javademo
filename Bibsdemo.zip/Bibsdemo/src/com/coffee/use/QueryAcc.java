package com.coffee.use;

/**
 * @ClassName QueryAcc
 * @description:
 * @author: coldcoffee
 * @create: 2024-06-15 10:09
 * @Version 1.0
 **/
public class QueryAcc {
}
