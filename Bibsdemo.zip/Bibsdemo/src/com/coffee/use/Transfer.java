package com.coffee.use;

/**
 * @ClassName Transfer
 * @description:
 * @author: coldcoffee
 * @create: 2024-06-15 10:12
 * @Version 1.0
 **/
public class Transfer {
}
