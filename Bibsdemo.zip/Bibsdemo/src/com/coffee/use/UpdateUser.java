package com.coffee.use;

/**
 * @ClassName UpdateUser
 * @description:
 * @author: coldcoffee
 * @create: 2024-06-15 10:11
 * @Version 1.0
 **/
public class UpdateUser {
}
