package com.coffee.use;

/**
 * @ClassName Register
 * @description:
 * @author: coldcoffee
 * @create: 2024-06-15 10:07
 * @Version 1.0
 **/
public class Register {
}
