package com.coffee.use;

/**
 * @ClassName UpdateAcc
 * @description:
 * @author: coldcoffee
 * @create: 2024-06-15 10:11
 * @Version 1.0
 **/
public class UpdateAcc {
}
