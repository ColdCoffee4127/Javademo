package com.coffee.use;

/**
 * @ClassName QueryUser
 * @description:
 * @author: coldcoffee
 * @create: 2024-06-15 10:10
 * @Version 1.0
 **/
public class QueryUser {
}
