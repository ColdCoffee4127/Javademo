package com.coffee.service;

public interface BibsService {
}
