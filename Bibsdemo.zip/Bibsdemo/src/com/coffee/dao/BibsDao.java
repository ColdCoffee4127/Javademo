package com.coffee.dao;

public interface BibsDao {
}
