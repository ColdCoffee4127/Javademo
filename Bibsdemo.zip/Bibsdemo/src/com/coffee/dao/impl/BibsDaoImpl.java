package com.coffee.dao.impl;

/**
 * @ClassName BibsDaoImpl
 * @description:
 * @author: coldcoffee
 * @create: 2024-06-15 11:43
 * @Version 1.0
 **/
public class BibsDaoImpl {
}
